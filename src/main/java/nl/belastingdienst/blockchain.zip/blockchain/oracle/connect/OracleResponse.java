package nl.belastingdienst.blockchain.oracle.connect;

import java.util.HashMap;
import java.util.Map;

import nl.belastingdienst.blockchain.oracle.domain.OracleContent;

public class OracleResponse {
	
	// van --> het DutchBdOracle
	private Map<String, OracleContent> requestedOracles = new HashMap<String, OracleContent>();

	// naar --> het smartContract
	private Long hashBlockChain;
	private String adressBlockChain;
	
	
	public Long getHash() {
		return hashBlockChain;
	}
	public void setHash(Long hash) {
		this.hashBlockChain = hash;
	}
	public String getAdress() {
		return adressBlockChain;
	}
	public void setAdress(String adress) {
		this.adressBlockChain = adress;
	}
	public Map<String, OracleContent> getRequestedOracles() {
		return requestedOracles;
	}
	public void setRequestedOracles(Map<String, OracleContent> requestedOracles) {
		this.requestedOracles = requestedOracles;
	}
}
