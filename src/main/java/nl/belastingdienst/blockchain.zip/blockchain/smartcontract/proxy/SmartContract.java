package nl.belastingdienst.blockchain.smartcontract.proxy;

public class SmartContract {

	private Long hash;
	
	public Long getHash() {
		return hash;
	}
}
